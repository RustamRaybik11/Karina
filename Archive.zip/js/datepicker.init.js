const start = datepicker('.start', { id: 1 })
const end = datepicker('.end', { id: 1 })
